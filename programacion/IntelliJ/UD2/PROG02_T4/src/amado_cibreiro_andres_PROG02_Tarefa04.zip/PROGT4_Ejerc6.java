public class PROGT4_Ejerc6 {
    public static void main(String[] args){
        float base=2.5f;
        float alto=4f;
        float area;
        area=(alto*base)/2;
        System.out.println("Área: "+area);
    }
}
