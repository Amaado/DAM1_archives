public class PROGT4_Ejerc1 {
    public static void main (String[] args){
        int x=144;
        int y=999;
        System.out.println("x= "+x);
        System.out.println("y= "+y);
        System.out.println("x + y= "+(x+y));
        System.out.println("x - y= "+(x-y));
        System.out.println("x * y= "+(x*y));
        System.out.println("x / y= "+(x/y));
    }
}
