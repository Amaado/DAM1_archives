public class PROGT4_Ejerc2 {
    public static void main(String[] args){
        String nombre="Andrés";
        String direccion="Santiago de Compostela, Rúa París, Portal 4, 3ºD";
        String telefono="669611818";
        System.out.println("Nombre: "+nombre+" Dirección: "+direccion+" Teléfono: "+telefono);
        System.out.println("Nombre: "+nombre);
        System.out.println("Dirección: "+direccion);
        System.out.println("Teléfono: "+telefono);
    }
}
