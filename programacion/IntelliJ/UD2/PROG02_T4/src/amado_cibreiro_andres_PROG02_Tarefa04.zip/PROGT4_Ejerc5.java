public class PROGT4_Ejerc5 {
    public static void main(String[] args){
        float largo=2.5f;
        float alto=4f;
        float area, perimetro;
        area=alto*largo;
        perimetro=(alto*2)+(largo*2);
        System.out.println("Perímetro: "+perimetro+"\nÁrea: "+area);
    }
}
