package Andres;

public class CuentaCorrientePersonal extends CuentaCorriente{
    private double comisionMantenimiento;

    public double getComisionMantenimiento() {
        return comisionMantenimiento;
    }

    public void setComisionMantenimiento(double comisionMantenimiento) {
        this.comisionMantenimiento = comisionMantenimiento;
    }
}
