package Andres;

public class Banco {
    private CuentaBancaria[] cuentas;
    int numCuentas;

    public Banco(CuentaBancaria[] cuentas, int numCuentas) {
        this.cuentas = cuentas;
        this.numCuentas = numCuentas;
    }

    public boolean abrirCuenta(CuentaBancaria){
        CuentaBancaria cuentaNueva = new Cuentaba
    }
}
