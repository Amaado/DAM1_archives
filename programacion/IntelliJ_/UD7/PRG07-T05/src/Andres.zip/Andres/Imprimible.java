package Andres;

public interface Imprimible {
    String DevolverInfoString();
}
